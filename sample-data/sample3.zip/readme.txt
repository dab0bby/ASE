This sample has an IPad as test object. 
The fact that the IPad has only a depth of 8mm makes it impossible to extract with the default parameters. 
This sample contains a config file. This file needs to be passed to the executable by the -c flag in order to make it work.